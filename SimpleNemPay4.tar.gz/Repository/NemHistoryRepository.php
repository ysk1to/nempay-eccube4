<?php

namespace Plugin\SimpleNemPay\Repository;

use Doctrine\ORM\EntityRepository;

class NemHistoryRepository extends EntityRepository
{
}
