<?php

namespace Plugin\SimpleNemPay;

use Eccube\Common\EccubeTwigBlock;

class SimpleNemPayTwigBlock implements EccubeTwigBlock
{
    /**
     * @return array
     */
    public static function getTwigBlock()
    {
        return [];
    }
}
